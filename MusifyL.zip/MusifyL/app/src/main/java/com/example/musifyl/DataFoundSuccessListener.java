package com.example.musifyl;

import com.google.firebase.database.DataSnapshot;

public interface DataFoundSuccessListener {
    void onSuccess(String url);
}
